module noise_cancel_top (
    input  logic        clk,
    input  logic        reset_n,
    input  logic [7:0]  avs_address,
    input  logic        avs_read,
    input  logic        avs_write,
    input  logic [31:0] avs_writedata,
    output logic [31:0] avs_readdata,
    output logic        aud_xck,
    output logic        aud_bclk,
    output logic        aud_daclrck,
    output logic        aud_adclrck,
    output logic        aud_dacdat,
    input  logic        aud_adcdat,
    inout  wire         fpga_i2c_sclk,
    inout  wire         fpga_i2c_sdat,
    output logic [9:0]  ledr
);

    // Internal audio samples and control signals all run in the audio clock domain.
    logic aud_lrck;
    logic signed [15:0] adc_l;
    logic signed [15:0] adc_r;
    logic adc_sample_valid;
    logic signed [15:0] lms_error;
    logic signed [31:0] coeff_data;
    logic lms_output_valid;
    logic lms_saturation;
    logic ctrl_enable;
    logic ctrl_reset_filter;
    logic ctrl_bypass;
    logic [15:0] mu;
    logic [5:0] coeff_addr;
    logic signed [15:0] primary_sample;
    logic signed [15:0] ref_sample;
    logic signed [15:0] error_sample;
    logic signed [15:0] dac_l;
    logic signed [15:0] dac_r;
    logic codec_data_alive;
    logic [11:0] codec_alive_count;
    logic [15:0] heartbeat_count;
    logic heartbeat;
    logic i2c_start;
    logic [6:0] i2c_codec_reg;
    logic [8:0] i2c_codec_data;
    logic i2c_busy;
    logic i2c_done;
    logic i2c_nack;
    logic scl_drive_low;
    logic sda_drive_low;

    assign aud_xck = clk;
    assign aud_daclrck = aud_lrck;
    assign aud_adclrck = aud_lrck;
    assign fpga_i2c_sclk = scl_drive_low ? 1'b0 : 1'bz;
    assign fpga_i2c_sdat = sda_drive_low ? 1'b0 : 1'bz;

    // Receive stereo samples from the WM8731 ADC: left is primary, right is reference.
    i2s_adc_rx adc_rx (
        .clk(clk),
        .reset_n(reset_n),
        .aud_bclk(aud_bclk),
        .aud_lrck(aud_lrck),
        .aud_adcdat(aud_adcdat),
        .adc_l_out(adc_l),
        .adc_r_out(adc_r),
        .sample_valid(adc_sample_valid)
    );

    // Adaptive filter estimates reference noise in the primary channel and outputs error.
    lms_filter lms (
        .clk(clk),
        .reset_n(reset_n),
        .enable(ctrl_enable),
        .reset_filter(ctrl_reset_filter),
        .d_in(adc_l),
        .x_in(adc_r),
        .mu(mu),
        .sample_valid(adc_sample_valid),
        .coeff_addr(coeff_addr),
        .e_out(lms_error),
        .coeff_data(coeff_data),
        .output_valid(lms_output_valid),
        .saturation(lms_saturation)
    );

    // Transmit either bypass stereo or mono LMS output back to the WM8731 DAC.
    i2s_dac_tx dac_tx (
        .clk(clk),
        .reset_n(reset_n),
        .dac_l_in(dac_l),
        .dac_r_in(dac_r),
        .aud_bclk(aud_bclk),
        .aud_lrck(aud_lrck),
        .aud_dacdat(aud_dacdat)
    );

    // Bit-banged I2C master used by software to initialize the WM8731 codec.
    i2c_controller i2c (
        .clk(clk),
        .reset_n(reset_n),
        .start(i2c_start),
        .codec_reg(i2c_codec_reg),
        .codec_data(i2c_codec_data),
        .busy(i2c_busy),
        .done(i2c_done),
        .nack(i2c_nack),
        .scl_drive_low(scl_drive_low),
        .sda_drive_low(sda_drive_low),
        .sda_in(fpga_i2c_sdat)
    );

    // Avalon-MM register block exposes controls, live samples, status, and I2C writes.
    avalon_slave regs (
        .clk(clk),
        .reset_n(reset_n),
        .address(avs_address),
        .read(avs_read),
        .write(avs_write),
        .writedata(avs_writedata),
        .readdata(avs_readdata),
        .enable(ctrl_enable),
        .reset_filter(ctrl_reset_filter),
        .bypass(ctrl_bypass),
        .mu(mu),
        .coeff_addr(coeff_addr),
        .coeff_data(coeff_data),
        .ref_sample(ref_sample),
        .primary_sample(primary_sample),
        .error_sample(error_sample),
        .codec_data_alive(codec_data_alive),
        .saturation_in(lms_saturation),
        .i2c_start(i2c_start),
        .i2c_codec_reg(i2c_codec_reg),
        .i2c_codec_data(i2c_codec_data),
        .i2c_busy(i2c_busy),
        .i2c_done(i2c_done),
        .i2c_nack(i2c_nack)
    );

    // Small VU display: use the top magnitude bits of the latest error sample.
    function automatic logic [5:0] vu_bits(input logic signed [15:0] sample);
        logic [15:0] magnitude;
        begin
            magnitude = sample[15] ? (~sample + 16'd1) : sample;
            vu_bits = magnitude[15:10];
        end
    endfunction

    always_ff @(posedge clk) begin
        if (!reset_n) begin
            primary_sample <= '0;
            ref_sample <= '0;
            error_sample <= '0;
            dac_l <= '0;
            dac_r <= '0;
            codec_alive_count <= '0;
            codec_data_alive <= 1'b0;
            heartbeat_count <= '0;
            heartbeat <= 1'b0;
            ledr <= '0;
        end else begin
            if (adc_sample_valid) begin
                // Snapshot live samples for software reads and status display.
                primary_sample <= adc_l;
                ref_sample <= adc_r;

                // Treat recent nonzero ADC data as proof that the codec stream is alive.
                if (adc_l != 16'sd0 || adc_r != 16'sd0) begin
                    codec_alive_count <= 12'hfff;
                end else if (codec_alive_count != 12'd0) begin
                    codec_alive_count <= codec_alive_count - 1'b1;
                end

                // Divide the 48 kHz sample pulse down to a slow LED heartbeat.
                if (heartbeat_count == 16'd23999) begin
                    heartbeat_count <= '0;
                    heartbeat <= ~heartbeat;
                end else begin
                    heartbeat_count <= heartbeat_count + 1'b1;
                end

                // Bypass mode sends raw stereo ADC samples directly to the DAC.
                if (ctrl_bypass) begin
                    dac_l <= adc_l;
                    dac_r <= adc_r;
                end
            end

            codec_data_alive <= (codec_alive_count != 12'd0);

            if (lms_output_valid) begin
                error_sample <= lms_error;
                // Normal mode sends the filtered mono error signal to both headphones.
                if (!ctrl_bypass) begin
                    dac_l <= lms_error;
                    dac_r <= lms_error;
                end
            end

            // LEDs show clock heartbeat, mode bits, saturation, and output magnitude.
            ledr[0] <= heartbeat;
            ledr[1] <= ctrl_enable;
            ledr[2] <= ctrl_bypass;
            ledr[3] <= lms_saturation;
            ledr[9:4] <= vu_bits(error_sample);
        end
    end

endmodule
