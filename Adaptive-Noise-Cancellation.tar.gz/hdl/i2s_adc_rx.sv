module i2s_adc_rx (
    input  logic               clk,
    input  logic               reset_n,
    input  logic               aud_bclk,
    input  logic               aud_lrck,
    input  logic               aud_adcdat,
    output logic signed [15:0] adc_l_out,
    output logic signed [15:0] adc_r_out,
    output logic               sample_valid
);

    // Edge-detect BCLK/LRCK in the local audio clock domain.
    logic bclk_d;
    logic lrck_d;
    logic receiving;
    logic [4:0] bit_count;
    logic shift_lrck;
    logic [15:0] shift_reg;

    always_ff @(posedge clk) begin
        if (!reset_n) begin
            bclk_d <= 1'b0;
            lrck_d <= 1'b0;
            receiving <= 1'b0;
            bit_count <= '0;
            shift_lrck <= 1'b0;
            shift_reg <= '0;
            adc_l_out <= '0;
            adc_r_out <= '0;
            sample_valid <= 1'b0;
        end else begin
            logic bclk_rise;
            logic lrck_changed;

            // The codec drives ADC data relative to BCLK; sample on BCLK rising edge.
            bclk_rise = !bclk_d && aud_bclk;
            lrck_changed = (aud_lrck != lrck_d);

            bclk_d <= aud_bclk;
            sample_valid <= 1'b0;

            if (bclk_rise) begin
                lrck_d <= aud_lrck;

                if (lrck_changed) begin
                    // LRCK edge starts a new 32-bit I2S half-frame.
                    receiving <= 1'b1;
                    bit_count <= 5'd0;
                    shift_lrck <= aud_lrck;
                    shift_reg <= '0;
                end else if (receiving) begin
                    if (bit_count < 5'd16) begin
                        logic [15:0] next_shift;

                        // Capture the 16 audio bits and ignore unused padding bits.
                        next_shift = {shift_reg[14:0], aud_adcdat};
                        shift_reg <= next_shift;

                        if (bit_count == 5'd15) begin
                            if (shift_lrck) begin
                                // Right word completes the stereo pair.
                                adc_r_out <= next_shift;
                                sample_valid <= 1'b1;
                            end else begin
                                // Left word is primary input for the LMS filter.
                                adc_l_out <= next_shift;
                            end
                        end
                    end

                    if (bit_count != 5'd31) begin
                        bit_count <= bit_count + 5'd1;
                    end
                end
            end
        end
    end

endmodule
