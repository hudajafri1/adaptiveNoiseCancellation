module avalon_slave (
    input  logic               clk,
    input  logic               reset_n,
    input  logic [7:0]         address,
    input  logic               read,
    input  logic               write,
    input  logic [31:0]        writedata,
    output logic [31:0]        readdata,

    output logic               enable,
    output logic               reset_filter,
    output logic               bypass,
    output logic [15:0]        mu,
    output logic [5:0]         coeff_addr,
    input  logic signed [31:0] coeff_data,
    input  logic signed [15:0] ref_sample,
    input  logic signed [15:0] primary_sample,
    input  logic signed [15:0] error_sample,
    input  logic               codec_data_alive,
    input  logic               saturation_in,

    output logic               i2c_start,
    output logic [6:0]         i2c_codec_reg,
    output logic [8:0]         i2c_codec_data,
    input  logic               i2c_busy,
    input  logic               i2c_done,
    input  logic               i2c_nack
);

    // Word-addressed register map exposed through the HPS lightweight bridge.
    localparam logic [31:0] MAGIC = 32'h4e43_3031; // "NC01"

    localparam logic [5:0] ADDR_MAGIC       = 6'h00;
    localparam logic [5:0] ADDR_CTRL        = 6'h01;
    localparam logic [5:0] ADDR_STATUS      = 6'h02;
    localparam logic [5:0] ADDR_MU          = 6'h03;
    localparam logic [5:0] ADDR_COEFF_ADDR  = 6'h04;
    localparam logic [5:0] ADDR_COEFF_DATA  = 6'h05;
    localparam logic [5:0] ADDR_REF_SAMPLE  = 6'h06;
    localparam logic [5:0] ADDR_PRI_SAMPLE  = 6'h07;
    localparam logic [5:0] ADDR_ERR_SAMPLE  = 6'h08;
    localparam logic [5:0] ADDR_I2C_CTRL    = 6'h09;
    localparam logic [5:0] ADDR_I2C_STATUS  = 6'h0a;

    logic saturation_sticky;
    logic mclk_lost_sticky;
    logic i2c_done_sticky;
    logic i2c_nack_sticky;
    logic i2c_last_ack_ok;

    // Avalon address is byte-based; registers are 32-bit word aligned.
    wire [5:0] word_addr = address[7:2];

    always_ff @(posedge clk) begin
        if (!reset_n) begin
            readdata <= '0;
            enable <= 1'b0;
            reset_filter <= 1'b0;
            bypass <= 1'b0;
            mu <= 16'h0200;
            coeff_addr <= '0;
            saturation_sticky <= 1'b0;
            mclk_lost_sticky <= 1'b0;
            i2c_start <= 1'b0;
            i2c_codec_reg <= '0;
            i2c_codec_data <= '0;
            i2c_done_sticky <= 1'b0;
            i2c_nack_sticky <= 1'b0;
            i2c_last_ack_ok <= 1'b0;
        end else begin
            // Pulse-type controls clear automatically unless software rewrites them.
            reset_filter <= 1'b0;
            i2c_start <= 1'b0;
            // Saturation stays set until software clears STATUS bit 3.
            saturation_sticky <= saturation_sticky | saturation_in;

            // I2C completion and NACK flags are sticky so software cannot miss them.
            if (i2c_done) begin
                i2c_done_sticky <= 1'b1;
                i2c_nack_sticky <= i2c_nack_sticky | i2c_nack;
                i2c_last_ack_ok <= !i2c_nack;
            end

            if (write) begin
                case (word_addr)
                    ADDR_CTRL: begin
                        // CTRL: enable LMS, reset coefficients, or bypass the filter.
                        enable <= writedata[0];
                        reset_filter <= writedata[1];
                        bypass <= writedata[2];
                    end

                    ADDR_STATUS: begin
                        // STATUS uses write-one-to-clear for sticky fault bits.
                        mclk_lost_sticky <= mclk_lost_sticky & !writedata[2];
                        saturation_sticky <= saturation_sticky & !writedata[3];
                    end

                    ADDR_MU: begin
                        // LMS adaptation rate, interpreted as unsigned Q0.16.
                        mu <= writedata[15:0];
                    end

                    ADDR_COEFF_ADDR: begin
                        // Select which LMS coefficient appears at COEFF_DATA.
                        coeff_addr <= writedata[5:0];
                    end

                    ADDR_I2C_CTRL: begin
                        if (!i2c_busy) begin
                            // Launch one codec register write when the I2C engine is idle.
                            i2c_codec_reg <= writedata[15:9];
                            i2c_codec_data <= writedata[8:0];
                            i2c_start <= 1'b1;
                            i2c_done_sticky <= 1'b0;
                            i2c_nack_sticky <= 1'b0;
                        end
                    end

                    ADDR_I2C_STATUS: begin
                        i2c_done_sticky <= i2c_done_sticky & !writedata[1];
                        i2c_nack_sticky <= i2c_nack_sticky & !writedata[2];
                    end

                    default: begin
                    end
                endcase
            end

            if (read) begin
                // Reads return status snapshots, controls, samples, coefficients, or I2C state.
                case (word_addr)
                    ADDR_MAGIC: begin
                        readdata <= MAGIC;
                    end

                    ADDR_CTRL: begin
                        readdata <= {29'b0, bypass, 1'b0, enable};
                    end

                    ADDR_STATUS: begin
                        readdata <= {28'b0, saturation_sticky, mclk_lost_sticky,
                                     codec_data_alive, 1'b1};
                    end

                    ADDR_MU: begin
                        readdata <= {16'b0, mu};
                    end

                    ADDR_COEFF_ADDR: begin
                        readdata <= {26'b0, coeff_addr};
                    end

                    ADDR_COEFF_DATA: begin
                        readdata <= coeff_data;
                    end

                    ADDR_REF_SAMPLE: begin
                        readdata <= {{16{ref_sample[15]}}, ref_sample};
                    end

                    ADDR_PRI_SAMPLE: begin
                        readdata <= {{16{primary_sample[15]}}, primary_sample};
                    end

                    ADDR_ERR_SAMPLE: begin
                        readdata <= {{16{error_sample[15]}}, error_sample};
                    end

                    ADDR_I2C_CTRL: begin
                        readdata <= {16'b0, i2c_codec_reg, i2c_codec_data};
                    end

                    ADDR_I2C_STATUS: begin
                        readdata <= {28'b0, i2c_last_ack_ok, i2c_nack_sticky,
                                     i2c_done_sticky, i2c_busy};
                    end

                    default: begin
                        readdata <= 32'h0;
                    end
                endcase
            end
        end
    end

endmodule
