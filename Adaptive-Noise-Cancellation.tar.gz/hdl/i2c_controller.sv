module i2c_controller #(
    parameter int CLK_HZ = 12_288_000,
    parameter int I2C_HZ = 100_000
) (
    input  logic       clk,
    input  logic       reset_n,
    input  logic       start,
    input  logic [6:0] codec_reg,
    input  logic [8:0] codec_data,
    output logic       busy,
    output logic       done,
    output logic       nack,
    output logic       scl_drive_low,
    output logic       sda_drive_low,
    input  logic       sda_in
);

    // Divide the audio clock down to a 100 kHz I2C half-period tick.
    localparam int HALF_DIV = (CLK_HZ / (I2C_HZ * 2));
    localparam int DIV_W = $clog2(HALF_DIV);
    localparam logic [DIV_W-1:0] HALF_DIV_LAST = HALF_DIV[DIV_W-1:0] - 1'b1;

    // Simple byte-write sequencer for the WM8731 control interface.
    typedef enum logic [3:0] {
        IDLE,
        START_HOLD,
        BIT_LOW,
        BIT_HIGH,
        ACK_LOW,
        ACK_HIGH,
        STOP_LOW,
        STOP_HIGH,
        COMPLETE
    } state_t;

    logic [DIV_W-1:0] div_count;
    logic [1:0] byte_idx;
    logic [2:0] bit_idx;
    logic [7:0] tx_bytes [0:2];
    state_t state;

    wire tick = (div_count == HALF_DIV_LAST);
    wire current_bit = tx_bytes[byte_idx][bit_idx];

    always_ff @(posedge clk) begin
        if (!reset_n) begin
            div_count <= '0;
            byte_idx <= '0;
            bit_idx <= 3'd7;
            tx_bytes[0] <= 8'h34;
            tx_bytes[1] <= '0;
            tx_bytes[2] <= '0;
            busy <= 1'b0;
            done <= 1'b0;
            nack <= 1'b0;
            scl_drive_low <= 1'b0;
            sda_drive_low <= 1'b0;
            state <= IDLE;
        end else begin
            done <= 1'b0;

            // The divider only runs while a transfer is active.
            if (busy) begin
                if (tick) begin
                    div_count <= '0;
                end else begin
                    div_count <= div_count + 1'b1;
                end
            end else begin
                div_count <= '0;
            end

            case (state)
                IDLE: begin
                    busy <= 1'b0;
                    scl_drive_low <= 1'b0;
                    sda_drive_low <= 1'b0;
                    if (start) begin
                        // WM8731 write format: device address, register/data MSBs, data LSBs.
                        tx_bytes[0] <= 8'h34;
                        tx_bytes[1] <= {codec_reg, codec_data[8]};
                        tx_bytes[2] <= codec_data[7:0];
                        byte_idx <= '0;
                        bit_idx <= 3'd7;
                        nack <= 1'b0;
                        busy <= 1'b1;
                        state <= START_HOLD;
                    end
                end

                START_HOLD: begin
                    // Start condition: SDA falls while SCL is released high.
                    scl_drive_low <= 1'b0;
                    sda_drive_low <= 1'b1;
                    if (tick) begin
                        state <= BIT_LOW;
                    end
                end

                BIT_LOW: begin
                    // Drive each data bit while SCL is low.
                    scl_drive_low <= 1'b1;
                    sda_drive_low <= !current_bit;
                    if (tick) begin
                        state <= BIT_HIGH;
                    end
                end

                BIT_HIGH: begin
                    // Release SCL high so the codec samples the current data bit.
                    scl_drive_low <= 1'b0;
                    sda_drive_low <= !current_bit;
                    if (tick) begin
                        if (bit_idx == 3'd0) begin
                            state <= ACK_LOW;
                        end else begin
                            bit_idx <= bit_idx - 1'b1;
                            state <= BIT_LOW;
                        end
                    end
                end

                ACK_LOW: begin
                    // Release SDA during ACK so the codec can pull it low.
                    scl_drive_low <= 1'b1;
                    sda_drive_low <= 1'b0;
                    if (tick) begin
                        state <= ACK_HIGH;
                    end
                end

                ACK_HIGH: begin
                    // Sample ACK/NACK with SCL high; any high ACK bit marks a NACK.
                    scl_drive_low <= 1'b0;
                    sda_drive_low <= 1'b0;
                    if (tick) begin
                        nack <= nack | sda_in;
                        if (byte_idx == 2'd2) begin
                            state <= STOP_LOW;
                        end else begin
                            byte_idx <= byte_idx + 1'b1;
                            bit_idx <= 3'd7;
                            state <= BIT_LOW;
                        end
                    end
                end

                STOP_LOW: begin
                    // Prepare stop with both lines low.
                    scl_drive_low <= 1'b1;
                    sda_drive_low <= 1'b1;
                    if (tick) begin
                        state <= STOP_HIGH;
                    end
                end

                STOP_HIGH: begin
                    // Stop condition: release SCL, then release SDA high.
                    scl_drive_low <= 1'b0;
                    sda_drive_low <= 1'b1;
                    if (tick) begin
                        state <= COMPLETE;
                    end
                end

                COMPLETE: begin
                    // One-cycle done pulse lets the register block latch the result.
                    scl_drive_low <= 1'b0;
                    sda_drive_low <= 1'b0;
                    busy <= 1'b0;
                    done <= 1'b1;
                    state <= IDLE;
                end

                default: begin
                    state <= IDLE;
                end
            endcase
        end
    end

endmodule
