module i2s_dac_tx (
    input  logic               clk,
    input  logic               reset_n,
    input  logic signed [15:0] dac_l_in,
    input  logic signed [15:0] dac_r_in,
    output logic               aud_bclk,
    output logic               aud_lrck,
    output logic               aud_dacdat
);

    // Generate 3.072 MHz BCLK from 12.288 MHz MCLK and step through 64 I2S slots.
    logic [1:0] bclk_div;
    logic [5:0] bit_slot;
    logic signed [15:0] left_sample;
    logic signed [15:0] right_sample;

    // LRCK selects left half-frame for slots 0-31 and right half-frame for slots 32-63.
    function automatic logic slot_lrck(input logic [5:0] slot);
        return slot[5];
    endfunction

    // I2S data is delayed one bit after LRCK transition, then sent MSB first.
    function automatic logic slot_data(
        input logic [5:0] slot,
        input logic signed [15:0] left_word,
        input logic signed [15:0] right_word
    );
        if (slot >= 6'd1 && slot <= 6'd16) begin
            return left_word[16 - slot];
        end else if (slot >= 6'd33 && slot <= 6'd48) begin
            return right_word[48 - slot];
        end else begin
            return 1'b0;
        end
    endfunction

    always_ff @(posedge clk) begin
        if (!reset_n) begin
            bclk_div <= 2'd0;
            bit_slot <= 6'd0;
            left_sample <= '0;
            right_sample <= '0;
            aud_bclk <= 1'b0;
            aud_lrck <= 1'b0;
            aud_dacdat <= 1'b0;
        end else begin
            bclk_div <= bclk_div + 2'd1;

            // Drive BCLK high in the middle of the 4-cycle divider period.
            if (bclk_div == 2'd1) begin
                aud_bclk <= 1'b1;
            end else if (bclk_div == 2'd3) begin
                logic [5:0] next_slot;

                // Advance the I2S frame on BCLK falling edge and update serial data.
                aud_bclk <= 1'b0;
                next_slot = bit_slot + 6'd1;
                bit_slot <= next_slot;

                if (next_slot == 6'd0) begin
                    // Latch the next stereo sample pair at the frame boundary.
                    left_sample <= dac_l_in;
                    right_sample <= dac_r_in;
                end

                aud_lrck <= slot_lrck(next_slot);
                aud_dacdat <= slot_data(next_slot, left_sample, right_sample);
            end
        end
    end

endmodule
