module lms_filter #(
    parameter int TAPS = 64
) (
    input  logic               clk,
    input  logic               reset_n,

    // enable=1 means run LMS adaptation. enable=0 means compute output only.
    input  logic               enable,

    // Clears learned coefficients and delay history without resetting the full FPGA.
    input  logic               reset_filter,

    // Primary mic input d[n]: speech plus background noise.
    input  logic signed [15:0] d_in,

    // Reference mic input x[n]: mostly background noise.
    input  logic signed [15:0] x_in,

    // LMS step size. Larger mu adapts faster but can become unstable.
    input  logic        [15:0] mu,

    // One-cycle pulse when a new stereo audio sample pair is ready.
    input  logic               sample_valid,

    // Software chooses which coefficient to inspect.
    input  logic        [5:0]  coeff_addr,

    // Error output e[n] = d[n] - estimated_noise[n].
    output logic signed [15:0] e_out,

    // Readback of one LMS coefficient for debug/monitoring.
    output logic signed [31:0] coeff_data,

    // Pulses high for one clock when e_out has a new valid sample.
    output logic               output_valid,

    // Sticky flag set if samples or coefficients saturate.
    output logic               saturation
);

    // Per-sample state machine. It computes one output sample across many clocks.
    typedef enum logic [2:0] {
        IDLE,           // Wait for sample_valid.
        MAC,            // Compute y[n] = sum(w[k] * x[n-k]).
        MAC_DRAIN,      // Add final registered MAC product.
        MAC_DONE,       // Compute e[n] and mu*e[n].
        UPDATE,         // Update each coefficient.
        UPDATE_DRAIN,   // Commit final registered update product.
        DONE            // Publish output sample.
    } state_t;

    // Enough bits to index every tap.
    localparam int TAP_INDEX_W = $clog2(TAPS);

    // Last valid tap index. For 64 taps this is 63.
    localparam logic [TAP_INDEX_W-1:0] LAST_TAP = '1;

    // Reference delay line. x_shift[0] is newest x[n].
    logic signed [15:0] x_shift [0:TAPS-1];

    // Adaptive FIR coefficients. These represent learned noise path.
    logic signed [31:0] weights [0:TAPS-1];

    // Wide accumulator for the FIR dot product.
    logic signed [63:0] acc;

    // Precomputed mu * e[n], reused for every tap update.
    logic signed [31:0] mu_e;

    // Registered multiplier outputs. The design uses one-cycle pipeline timing.
    logic signed [47:0] mac_product_reg;
    logic signed [47:0] update_product_reg;

    // Latched primary sample and final error for the current frame.
    logic signed [15:0] d_reg;
    logic signed [15:0] e_reg;

    // Current tap index for MAC/update sweeps.
    logic [TAP_INDEX_W-1:0] tap_idx;

    // Remembers which coefficient matches update_product_reg.
    logic [TAP_INDEX_W-1:0] update_tap_reg;

    // Latches enable at sample start so mode changes do not affect half a frame.
    logic sample_enable;

    // Saturation seen during the current sample computation.
    logic sample_saturation;

    // Valid flags prevent using stale multiplier output on first cycle.
    logic mac_product_valid;
    logic update_product_valid;

    state_t state;

    // Clamp a wide signed value into 16-bit Q1.15 audio sample range.
    function automatic logic signed [15:0] sat_q1_15(input logic signed [63:0] value);
        if (value > 64'sd32767) begin
            return 16'sh7fff;
        end else if (value < -64'sd32768) begin
            return 16'sh8000;
        end else begin
            return value[15:0];
        end
    endfunction

    // Clamp a wide signed value into 32-bit Q2.30 coefficient range.
    function automatic logic signed [31:0] sat_q2_30(input logic signed [63:0] value);
        if (value > 64'sd2147483647) begin
            return 32'sh7fff_ffff;
        end else if (value < -64'sd2147483648) begin
            return 32'sh8000_0000;
        end else begin
            return value[31:0];
        end
    endfunction

    // Detect whether a value would overflow signed Q1.15.
    function automatic logic overflow_q1_15(input logic signed [63:0] value);
        return (value > 64'sd32767) || (value < -64'sd32768);
    endfunction

    // Detect whether a value would overflow signed Q2.30.
    function automatic logic overflow_q2_30(input logic signed [63:0] value);
        return (value > 64'sd2147483647) || (value < -64'sd2147483648);
    endfunction

    always_comb begin
        // Combinational coefficient readback for software debug.
        coeff_data = weights[coeff_addr];
    end

    always_ff @(posedge clk) begin
        if (!reset_n) begin
            // Full hardware reset clears delay line, coefficients, and pipeline state.
            for (int i = 0; i < TAPS; i++) begin
                x_shift[i] <= '0;
                weights[i] <= '0;
            end

            acc <= '0;
            mu_e <= '0;
            mac_product_reg <= '0;
            update_product_reg <= '0;
            d_reg <= '0;
            e_reg <= '0;
            e_out <= '0;
            output_valid <= 1'b0;
            saturation <= 1'b0;
            sample_saturation <= 1'b0;
            sample_enable <= 1'b0;
            tap_idx <= '0;
            update_tap_reg <= '0;
            mac_product_valid <= 1'b0;
            update_product_valid <= 1'b0;
            state <= IDLE;
        end else if (reset_filter) begin
            // Software reset clears the learned LMS model so it can relearn.
            for (int i = 0; i < TAPS; i++) begin
                x_shift[i] <= '0;
                weights[i] <= '0;
            end

            acc <= '0;
            mu_e <= '0;
            mac_product_reg <= '0;
            update_product_reg <= '0;
            d_reg <= '0;
            e_reg <= '0;
            e_out <= '0;
            output_valid <= 1'b0;
            saturation <= 1'b0;
            sample_saturation <= 1'b0;
            sample_enable <= 1'b0;
            tap_idx <= '0;
            update_tap_reg <= '0;
            mac_product_valid <= 1'b0;
            update_product_valid <= 1'b0;
            state <= IDLE;
        end else begin
            // output_valid is a pulse, so default low each clock.
            output_valid <= 1'b0;

            case (state)
                IDLE: begin
                    if (sample_valid) begin
                        // Shift reference history older by one tap.
                        for (int i = TAPS - 1; i > 0; i--) begin
                            x_shift[i] <= x_shift[i-1];
                        end

                        // Insert newest reference noise sample.
                        x_shift[0] <= x_in;

                        // Latch matching primary sample for this frame.
                        d_reg <= d_in;

                        // Clear per-sample computation state.
                        acc <= '0;
                        sample_saturation <= 1'b0;
                        sample_enable <= enable;
                        tap_idx <= '0;
                        mac_product_valid <= 1'b0;
                        update_product_valid <= 1'b0;

                        // Begin FIR estimate of the noise.
                        state <= MAC;
                    end
                end

                MAC: begin
                    logic signed [47:0] product;

                    // Launch multiply for current tap: x[n-k] * w[k].
                    product = x_shift[tap_idx] * weights[tap_idx];
                    mac_product_reg <= product;

                    // Add previous cycle's registered product into accumulator.
                    if (mac_product_valid) begin
                        acc <= acc + {{16{mac_product_reg[47]}}, mac_product_reg};
                    end

                    // From now on, mac_product_reg contains useful data.
                    mac_product_valid <= 1'b1;

                    // After launching final tap multiply, drain final registered product.
                    if (tap_idx == LAST_TAP) begin
                        tap_idx <= '0;
                        state <= MAC_DRAIN;
                    end else begin
                        tap_idx <= tap_idx + 1'b1;
                    end
                end

                MAC_DRAIN: begin
                    // Add the final product that was launched during the last MAC cycle.
                    if (mac_product_valid) begin
                        acc <= acc + {{16{mac_product_reg[47]}}, mac_product_reg};
                    end

                    mac_product_valid <= 1'b0;
                    state <= MAC_DONE;
                end

                MAC_DONE: begin
                    logic signed [15:0] y;
                    logic signed [63:0] y_narrow;
                    logic signed [63:0] e_wide;
                    logic signed [32:0] mu_product;

                    // Convert accumulated FIR estimate back toward Q1.15 sample scale.
                    y_narrow = acc >>> 30;
                    y = sat_q1_15(y_narrow);

                    // Subtract estimated noise from primary mic: e[n] = d[n] - y[n].
                    e_wide = {{48{d_reg[15]}}, d_reg} - {{48{y[15]}}, y};
                    e_reg <= sat_q1_15(e_wide);

                    // Precompute mu*e[n] once before coefficient update loop.
                    mu_product = $signed({1'b0, mu}) * $signed(sat_q1_15(e_wide));
                    mu_e <= mu_product[31:0];

                    // Record if y[n] or e[n] clipped.
                    sample_saturation <= sample_saturation | overflow_q1_15(y_narrow) | overflow_q1_15(e_wide);

                    tap_idx <= '0;
                    update_product_valid <= 1'b0;

                    // If LMS is enabled, update weights. Otherwise just output e[n].
                    state <= sample_enable ? UPDATE : DONE;
                end

                UPDATE: begin
                    logic signed [47:0] update_product;
                    logic signed [63:0] weight_q2_46;
                    logic signed [63:0] update_sum;
                    logic signed [63:0] weight_next;

                    // Launch LMS update term: mu * e[n] * x[n-k].
                    update_product = mu_e * x_shift[tap_idx];
                    update_product_reg <= update_product;

                    // Remember which tap this registered product belongs to.
                    update_tap_reg <= tap_idx;

                    // Apply previous cycle's update product to its coefficient.
                    if (update_product_valid) begin
                        // Align old Q2.30 weight to Q2.46 before adding update.
                        weight_q2_46 = {{16{weights[update_tap_reg][31]}}, weights[update_tap_reg], 16'b0};

                        // Add signed update product.
                        update_sum = weight_q2_46 + {{16{update_product_reg[47]}}, update_product_reg};

                        // Shift back to Q2.30 coefficient scale.
                        weight_next = update_sum >>> 16;

                        // Store clamped coefficient.
                        weights[update_tap_reg] <= sat_q2_30(weight_next);

                        // Record coefficient overflow if it happened.
                        sample_saturation <= sample_saturation | overflow_q2_30(weight_next);
                    end

                    update_product_valid <= 1'b1;

                    // Sweep all taps.
                    if (tap_idx == LAST_TAP) begin
                        state <= UPDATE_DRAIN;
                    end else begin
                        tap_idx <= tap_idx + 1'b1;
                    end
                end

                UPDATE_DRAIN: begin
                    logic signed [63:0] weight_q2_46;
                    logic signed [63:0] update_sum;
                    logic signed [63:0] weight_next;

                    // Commit the final registered update product from the UPDATE state.
                    if (update_product_valid) begin
                        weight_q2_46 = {{16{weights[update_tap_reg][31]}}, weights[update_tap_reg], 16'b0};
                        update_sum = weight_q2_46 + {{16{update_product_reg[47]}}, update_product_reg};
                        weight_next = update_sum >>> 16;

                        weights[update_tap_reg] <= sat_q2_30(weight_next);
                        sample_saturation <= sample_saturation | overflow_q2_30(weight_next);
                    end

                    update_product_valid <= 1'b0;
                    state <= DONE;
                end

                DONE: begin
                    // Publish filtered output sample.
                    e_out <= e_reg;
                    output_valid <= 1'b1;

                    // Merge this sample's saturation into sticky status.
                    saturation <= saturation | sample_saturation;

                    // Ready for the next audio sample.
                    state <= IDLE;
                end

                default: begin
                    // Recovery path if state somehow becomes invalid.
                    state <= IDLE;
                end
            endcase
        end
    end
endmodule
