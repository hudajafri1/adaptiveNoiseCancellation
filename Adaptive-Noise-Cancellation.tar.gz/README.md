# Real-Time Two-Microphone Adaptive Noise Cancellation

Embedded systems final project (CSEE 4840). DE1-SoC + WM8731 codec + 64-tap FPGA LMS filter + HPS Linux control.

**Read [PLAN.md](PLAN.md) before doing anything else.** It is the single source of truth for architecture, phases, register map, and demo script.

## 30-Second Quick Start (assumes you've finished Phase 5)

```bash
# Workstation: build and load the FPGA bitstream
make qsys && make quartus && make program

# Workstation: push software to the board
./scripts/deploy.sh <board-ip>

# Board (over ssh):
cd ~/nc_sw
make all
sudo insmod kernel/noise_cancel_drv.ko
./user/nc_codec --init
./user/nc_demo                        # interactive: press 'b' for bypass, 'r' to reset, '+'/'-' for mu
```

## What's in this repo

| Directory | Contents |
| --- | --- |
| `hdl/` | SystemVerilog source (LMS, I²S, register file, top wrapper) |
| `sim/` | Verilator test benches |
| `quartus/` | Quartus project + Platform Designer system |
| `hw/` | Platform Designer component spec |
| `sw/kernel/` | Linux device driver |
| `sw/user/` | Userspace demo + codec config + monitor |
| `scripts/` | Deploy, flash, debug helpers |
| `docs/` | Demo script + register map |

## Top-level make targets

```
make help        # list everything
make sim         # run Verilator simulations
make qsys        # regenerate Platform Designer system
make quartus     # full FPGA compilation (5-15 min)
make phase1      # run Phase 1 skeleton checks
make phase2      # run Phase 2 LMS simulation
make sim-lms     # run just the LMS simulation
make sim-i2s     # run Phase 3 I2S loopback once implemented
make program     # JTAG-load .sof to a connected board
make rbf         # build .rbf for SD-card boot
make flash       # copy .rbf + .dtb to board boot partition
make clean       # delete all generated files
```

## Where to look when something breaks

`PLAN.md` §8 (Failure-Mode Catalog) and §10 (Common Debug Recipes) cover the issues we expect to hit, with the fastest fix for each.
