package require -exact qsys 13.0

set_module_property NAME noise_cancel
set_module_property DISPLAY_NAME "Noise Cancel"
set_module_property VERSION 1.0
set_module_property GROUP "CSEE4840/Audio"
set_module_property DESCRIPTION "Two-microphone LMS adaptive noise cancellation peripheral"
set_module_property AUTHOR "CSEE4840"
set_module_property INSTANTIATE_IN_SYSTEM_MODULE true
set_module_property EDITABLE false
set_module_assignment embeddedsw.dts.vendor "csee4840"
set_module_assignment embeddedsw.dts.name "noise_cancel"
set_module_assignment embeddedsw.dts.compatible "csee4840,noise_cancel-1.0"
set_module_assignment embeddedsw.dts.group "audio"

add_fileset QUARTUS_SYNTH QUARTUS_SYNTH "" ""
set_fileset_property QUARTUS_SYNTH TOP_LEVEL noise_cancel_top
add_fileset_file noise_cancel_top.sv SYSTEM_VERILOG PATH ../hdl/noise_cancel_top.sv TOP_LEVEL_FILE
add_fileset_file avalon_slave.sv SYSTEM_VERILOG PATH ../hdl/avalon_slave.sv
add_fileset_file i2c_controller.sv SYSTEM_VERILOG PATH ../hdl/i2c_controller.sv
add_fileset_file i2s_adc_rx.sv SYSTEM_VERILOG PATH ../hdl/i2s_adc_rx.sv
add_fileset_file i2s_dac_tx.sv SYSTEM_VERILOG PATH ../hdl/i2s_dac_tx.sv
add_fileset_file lms_filter.sv SYSTEM_VERILOG PATH ../hdl/lms_filter.sv

add_interface clk clock end
set_interface_property clk clockRate 12288135
add_interface_port clk clk clk Input 1

add_interface reset reset end
set_interface_property reset associatedClock clk
set_interface_property reset synchronousEdges DEASSERT
add_interface_port reset reset_n reset_n Input 1

add_interface avalon_slave_0 avalon end
set_interface_property avalon_slave_0 associatedClock clk
set_interface_property avalon_slave_0 associatedReset reset
set_interface_property avalon_slave_0 addressUnits SYMBOLS
set_interface_property avalon_slave_0 bitsPerSymbol 8
set_interface_property avalon_slave_0 maximumPendingReadTransactions 0
set_interface_property avalon_slave_0 readLatency 1
set_interface_property avalon_slave_0 readWaitTime 0
set_interface_property avalon_slave_0 writeWaitTime 0
set_interface_property avalon_slave_0 holdTime 0
set_interface_property avalon_slave_0 setupTime 0
add_interface_port avalon_slave_0 avs_address address Input 8
add_interface_port avalon_slave_0 avs_read read Input 1
add_interface_port avalon_slave_0 avs_write write Input 1
add_interface_port avalon_slave_0 avs_writedata writedata Input 32
add_interface_port avalon_slave_0 avs_readdata readdata Output 32

add_interface audio conduit end
set_interface_property audio associatedClock clk
add_interface_port audio aud_xck export Output 1
add_interface_port audio aud_bclk export Output 1
add_interface_port audio aud_daclrck export Output 1
add_interface_port audio aud_adclrck export Output 1
add_interface_port audio aud_dacdat export Output 1
add_interface_port audio aud_adcdat export Input 1
add_interface_port audio fpga_i2c_sclk export Bidir 1
add_interface_port audio fpga_i2c_sdat export Bidir 1
add_interface_port audio ledr export Output 10
