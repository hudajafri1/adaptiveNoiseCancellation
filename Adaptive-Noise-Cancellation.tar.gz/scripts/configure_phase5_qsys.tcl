package require -exact qsys 21.1

proc remove_connection_if_present {connection_name} {
    if {[lsearch -exact [get_connections] $connection_name] >= 0} {
        remove_connection $connection_name
    }
}

proc remove_interface_if_present {interface_name} {
    if {[lsearch -exact [get_interfaces] $interface_name] >= 0} {
        remove_interface $interface_name
    }
}

proc remove_instance_if_present {instance_name} {
    if {[lsearch -exact [get_instances] $instance_name] >= 0} {
        remove_instance $instance_name
    }
}

remove_connection_if_present clk_0.clk/vga_ball_0.clock
remove_connection_if_present clk_0.clk_reset/vga_ball_0.reset
remove_connection_if_present hps_0.h2f_lw_axi_master/vga_ball_0.avalon_slave_0
remove_interface_if_present vga
remove_instance_if_present vga_ball_0

remove_instance_if_present audio_pll_0
remove_instance_if_present noise_cancel_0
remove_interface_if_present audio

add_instance audio_pll_0 altera_pll 21.1
set_instance_parameter_value audio_pll_0 device_family "Cyclone V"
set_instance_parameter_value audio_pll_0 device 5CSEMA5F31C6
set_instance_parameter_value audio_pll_0 gui_reference_clock_frequency 50.0
set_instance_parameter_value audio_pll_0 reference_clock_frequency "50.0 MHz"
set_instance_parameter_value audio_pll_0 gui_number_of_clocks 1
set_instance_parameter_value audio_pll_0 number_of_clocks 1
set_instance_parameter_value audio_pll_0 gui_output_clock_frequency0 12.288
set_instance_parameter_value audio_pll_0 output_clock_frequency0 "12.288 MHz"
set_instance_parameter_value audio_pll_0 gui_use_locked true

add_instance noise_cancel_0 noise_cancel 1.0

add_connection clk_0.clk audio_pll_0.refclk
add_connection clk_0.clk_reset audio_pll_0.reset
add_connection audio_pll_0.outclk0 noise_cancel_0.clk
add_connection clk_0.clk_reset noise_cancel_0.reset
add_connection hps_0.h2f_lw_axi_master noise_cancel_0.avalon_slave_0
set_connection_parameter_value hps_0.h2f_lw_axi_master/noise_cancel_0.avalon_slave_0 baseAddress 0x0000

add_interface audio conduit end
set_interface_property audio EXPORT_OF noise_cancel_0.audio

save_system
